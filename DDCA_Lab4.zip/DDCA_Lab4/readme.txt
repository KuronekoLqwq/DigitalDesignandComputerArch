Most of the idea is in the comment. 

Here is a tricky point: try to set tb_FSM line 68 to #14, then check the waveform.
It seem like only when left/right signal covers the second negedge, it works correctly.
Why? Is it important? 

If the results of your schematic in elaborated design aren't corresponding to the schematic in synthesis, open tools/settings/synthesis, and set -fsm_extraction off. 
The 'optimize' may cause an error and change your circuit. 