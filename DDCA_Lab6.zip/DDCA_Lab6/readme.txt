When you editing the testvector, if the input has some bug, clear all the spaces. You can find the uncostomized value in the lab6-files.zip 

There are 3 errors, in my ALU in lab5. I've noted and fixed it in lab 6. You can import the ALU in my lab5 to find it yourself. 

If you can't find all the testvector, add the simulation time in tools->settings->simulation->simulation->xsim.simulate.runtime


When simulating the bad_ALU, remember to set it as Top. 