For the design of adder, you can try more ideas including ripple-carry, carry-lookahead, carry-save, 3:2 compressors. 
The usage of generate will make it easier for you to get a bigger adder such as 16 bits. 
Ref: https://en.wikipedia.org/wiki/Adder_%28electronics%29

For the testbench, you can test all the case with an easy accessible golden model - '+'. 
