For the design of decoder, I love to use pos directly, but sometimes it's easy to lost some items...
So a comprehensive testbench is necessary! You need to cover all the parts of the truthtable to test every case, and I found my bug by the way. 
To make it less stupid, check my testbench. 

For the constraint file, based on the given tutorial, remember to add the constraint for overflow bit LED. Otherwise you can't generate the bitstream. 

