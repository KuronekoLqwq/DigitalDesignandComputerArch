Because the next lab is testing the ALU, I won't test the ALU here. 

The usage of LUT is slightly low comparing to the lab manual, because I use a costomized adder instead of +. You can try more advanced adder here. 